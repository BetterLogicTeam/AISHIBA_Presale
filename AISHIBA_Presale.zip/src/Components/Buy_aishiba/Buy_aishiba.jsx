import React from 'react'
import "./Buy_aishiba.css"

export default function Buy_aishiba() {
  return (
    <div className='buy_ashi_main'>
<h1 className='buy_heading_ash'>
    how to buy aishiba 
</h1>
    
    <div className="container">
<p className='text-white text-center'>
Take the lead and secure your Aishiba tokens in the presale using ETH, BNB, USDT, BUSD before it hits the DEX listing. Don't miss out on this opportunity to be part of the Aishiba revolution!

{/* Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi sed porro modi temporibus voluptate ad! Quasi natus, nesciunt distinctio id alias praesentium similique dolorum enim provident aperiam quia a ipsam. */}
</p>
        <div className="row">
            <div className="col-md-4 ">
                <div className="buy_cards text-white text-center">
                <h1 className='text-white text-center'>1.</h1>
                <p>
                Transfer ETH or BNB to your Metamask or Trust Wallet and proceed to purchase AISHIBA tokens using your preferred blockchain.
                </p>

                </div>
            </div>
            <div className="col-md-4 mt-3 mt-md-0">
                <div className="buy_cards text-white text-center">
                <h1 className='text-white text-center'>2.</h1>
                <p>
                You can also buy $AISHIBA tokens with USDT ( BEP-20), BUSD ( BEP-20 ). Use the USDT option and Buy your desired amount.
                </p>

                </div>
            </div>
            <div className="col-md-4 mt-3 mt-md-0">
                <div className="buy_cards text-white text-center">
                <h1 className='text-white text-center'>3.</h1>
                <p>
                Congratulations on successfully purchasing AISHIBA tokens! Now, it's time to enjoy and participate in the AISHIBA ecosystem.    
                </p>

                </div>
            </div>
        </div>
    </div>
    
    
    </div>
  )
}
